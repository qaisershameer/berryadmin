class QImages{

  QImages._();

  /// main images
  static const String dashboard = 'assets/images/dashboard.png';

  static const String banner1 = 'assets/images/banner1.png';

  /// Settings images
  static const String menu = 'assets/images/menu.png';
  static const String profile = 'assets/images/profile.png';
  static const String logout = 'assets/images/logout.png';
  static const String success = 'assets/images/success.png';

  /// Social  images
  static const String facebook = 'assets/images/facebook.png';
  static const String google = 'assets/images/google.png';

  /// Shopping Products images

  static const String cart = 'assets/images/cart.png';


}