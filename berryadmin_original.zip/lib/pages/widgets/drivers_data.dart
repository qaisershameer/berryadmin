import 'package:berryadmin/common_widgets/q_widgets.dart';
import 'package:berryadmin/utils/q_const.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:image_network/image_network.dart';

import '../../utils/q_colors.dart';

class DriversData extends StatefulWidget {
  const DriversData({super.key});

  @override
  State<DriversData> createState() => _DriversDataState();
}

class _DriversDataState extends State<DriversData> {
  final driversRefFromDB = FirebaseDatabase.instance.ref().child(QConst.driversCollection);
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: driversRefFromDB.onValue,
        builder: (context, snapshotData) {

          /// if Error loading data
          if (snapshotData.hasError) {
            return Center(child: Text('Error Occurred Drivers Collection, try later...'));
          }

          /// if snapshot data is on waiting
          if (snapshotData.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator(color: QColors.primary));
          }

          /// Check if data is null
          final dataSnapshot = snapshotData.data?.snapshot;
          if (dataSnapshot == null || dataSnapshot.value == null) {
            return Center(child: Text('No drivers found.'));
          }

          /// Extract Data from Firebase DB
          Map driverDataMap = snapshotData.data!.snapshot.value as Map;
          List driversList =[];

          /// loop data and add data in Drivers List
          driverDataMap.forEach((key, value) => driversList.add({'key': key, ...value}));

          /// display data for UI
          return ListView.builder(
            shrinkWrap: true,
            itemCount: driversList.length,
              itemBuilder: (context, index) {

              return SingleChildScrollView(
                scrollDirection: Axis.horizontal,

                child: Row(
                    children: [

                      /// Data Detail Fields
                      QWidgets.dataContainer(colWidth: 250, widget: Text(driversList[index]['driverId'].toString())),
                      QWidgets.dataContainer(colWidth: 100, widget: ImageNetwork(image: driversList[index]['photo'].toString(), height: 70, width: 70)),
                      QWidgets.dataContainer(colWidth: 120, widget: Text(driversList[index]['name'].toString())),
                      QWidgets.dataContainer(colWidth: 200, widget: Text(driversList[index]['car_details']['carModel'].toString())),
                      QWidgets.dataContainer(colWidth: 120, widget: Text(driversList[index]['phone'].toString())),
                      QWidgets.dataContainer(colWidth: 150, widget: driversList[index]['earnings'] != null ? Text(driversList[index]['earnings'].toString()) : Text('\$ 0')),

                      /// Widget Action Buttons
                      QWidgets.dataContainer(colWidth: 300, widget:

                        Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [

                                driversList[index]['blockStatus'] == 'no'
                                  /// Block Button
                                  ? ElevatedButton(onPressed: () async {await driversRefFromDB.child(driversList[index]['key']).update({'blockStatus': 'yes'});},
                                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                                    child: Text('Block', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)))

                                  /// Approve Button
                                  : ElevatedButton(onPressed: () async {await driversRefFromDB.child(driversList[index]['key']).update({'blockStatus': 'no'});},
                                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                                    child: Text('Approve', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),

                                /// Buttons Gap
                                SizedBox(width: 8.0),

                                /// Delete Button
                                ElevatedButton(onPressed: () async {
                                  /// Delete Confirmation
                                  bool confirmDel = await _showAlertDialog(context);
                                    if(confirmDel){
                                      await driversRefFromDB.child(driversList[index]['driverId']).remove();
                                    }
                                  },
                                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                                    child: Text('Delete', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)
                                    ),
                                ),
                              ],
                        ),
                      )
                    ]
                ),
              );

            }
          );

        }
    );

  }
}

Future<bool> _showAlertDialog(BuildContext context) async {
  return await showDialog(context: context, builder: (context) {
   return AlertDialog(
     title: const Text('Confirm Deletion!'),
     content: const Text('Are you sure! want to delete this record???'),
     actions: [
       TextButton(onPressed: (){Navigator.of(context).pop(false);}, child: const Text('Cancel')),
       TextButton(onPressed: (){Navigator.of(context).pop(true);}, child: const Text('Delete')),
     ],
   );
  }) ?? false;
}